<?php 
require 'config/db.php';
$stmt = $conn->query("SELECT * FROM cimg");
$stmt->execute();
$bg = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$bg) { 
 } else {
   $bg = $bg['img'];
 }?>


         

     
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
header {
    background: url('admin/BG/<?php echo $bg;?>');
    background-attachment: fixed;
}
  </style>

</head>
<body>
    
</body>
</html>