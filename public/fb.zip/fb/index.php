<?php 
require 'config/db.php';
require 'bg.php';

$stmt = $conn->query("SELECT * FROM pfb_b");
$stmt->execute();
$pixels = $stmt->fetchAll(); 


$stmt = $conn->query("SELECT * FROM imges");
$stmt->execute();
$imges = $stmt->fetchAll(); 


$stmt = $conn->query("SELECT * FROM logos");
$stmt->execute();
$modals = $stmt->fetchAll(); 


$stmt = $conn->query("SELECT * FROM cimg");
$stmt->execute();
$bgimg = $stmt->fetchAll();


$stmt = $conn->query("SELECT * FROM modal");
$stmt->execute();
$modal = $stmt->fetchAll();





$uipa=$_SERVER['REMOTE_ADDR'];




    $checkSql = $conn->prepare("SELECT COUNT(*) FROM ipa WHERE uipa = :uipa");
    $checkSql->bindParam(":uipa", $uipa);
    $checkSql->execute();
    $rowCount = $checkSql->fetchColumn();

    if ($rowCount == 0) {
    
    $sql = $conn->prepare("INSERT INTO ipa(uipa) VALUES(:uipa)");
    $sql->bindParam(":uipa", $uipa);
    $sql->execute();
    
    if ($sql){

    }
    
} else {
  
}



?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>พร้อมบริการลูกค้า ทุกท่าน ตลอด24ชม</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
 <!---pixel----->
 <?php 

if (!$modal) { ?>
  <style>
    #section {
      overflow: hidden;
      display: block;
    }

    #main {
      overflow: hidden;
      display: none;
    }
    .imge {
        max-width:400px;
        margin: auto;
    }
    img {
        width: 100%;
    }

  
  </style>

<?php
} else { 
  
  $ximg = "100";
  
  ?>
 
 <style>
    #section {
      overflow: hidden;
      display: none;
    }

    #main {
      overflow: hidden;
      display: block;
    }
    

  
  </style>
 <?php
} 











$stmt = $conn->query("SELECT * FROM pfb_b");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) { 
 } else {  
 $pixel = $row['pixel'];}?>
 <?php echo $pixel; ?>
 <!---pixel----->


<style>
    .imge {
        max-width: 400px;
        margin: auto;
    }
    img {
        width: 100%;
    }
</style>


 <?php
if(!$bgimg) {

} else {
  foreach($bgimg as $bg)  { 
       $img = $bg['img'];?>
  <?php }} 
   if($ximg = 100)  {   ?>

<style>
  body {
    background: url("admin/BG/<?php echo $img; ?>");
  }
  </style>

<?php
   }  
  ?>
   

  






</head>
<body>


  
<section id="section">  
<div class="container">
 <div class="imge">
  <a href="web.php" class="button" id="button" type="button" >
  <?php
 if (!$imges) { ?>
    <?php  } else {

  foreach($imges as $imgee)  { ?>
        
     
      <img src="admin/img_up/<?php echo $imgee['img'];?>" width="100" alt="">

      <?php }} ?>
      </a>
 </div>
</div>

  </a>



<div class="fixed-bottom m-2 ">
<div class="text-bg-light p-3">

<div class="text-center">
<a href="web.php" type="button" class="btn btn-success w-25 rounded-pill">สมัครสมาชิก</a>
</div>


</div>


</div>

</section>
<main id="main">











<link rel="stylesheet" href="style.css">

<nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
              
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#!"></a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="https://www.facebook.com/meedee88shopping/" role="button" data-bs-toggle="dropdown" aria-expanded="false"></a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                               
                            </ul>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <button class="btn btn-outline-dark" type="submit">
                            <i class="bi-cart-fill me-1"></i>
                            Cart
                            <span class="badge bg-dark text-white ms-1 rounded-pill">1</span>
                        </button>
                    </form>
                </div>
            </div>
        </nav>
        <!-- Header-->
        <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">โทรศัพท์ PG v9 </h1>
                    <p class="lead fw-normal text-white-50 mb-0">สมาร์ทโฟนจอใหญ่ ราคาถูก เบอร์โทร 
                        022970360</p>
                </div>
            </div>
        </header>
        <!-- Section-->
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="img/1.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product price-->
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">View options</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="img/2.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">1,999 บาท</span>
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">Add to cart</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="img/3.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">1,999 บาท</span>
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">Add to cart</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="img/4.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">Add to cart</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="img/5.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">$50.00</span>
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">Add to cart</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="img/6.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product price-->
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">View options</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="img/7.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">$20.00</span>
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">Add to cart</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="img/8.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">โทรศัพท์ PG v9</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    1,099 บาท
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="https://www.facebook.com/meedee88shopping/">โทรศัพท์ PG v9</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">โทรศัพท์ PG v9 &copy; โทรศัพท์ PG v9 2023 เบอร์โทร 
                022970360</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>

















</main>

</body>
</html>